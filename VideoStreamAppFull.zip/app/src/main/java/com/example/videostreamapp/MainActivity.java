package com.example.videostreamapp;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.RenderersFactory;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.ui.PlayerView;

public class MainActivity extends AppCompatActivity {

    private PlayerView playerView;
    private EditText urlInput;
    private Button playButton, addVideoButton, checkSelectedButton;
    private Switch audioSwitch, videoSwitch, liveSwitch, decodeSwitch;
    private ExoPlayer player;
    private boolean isMuted = false;
    private boolean isPlaying = false;
    private boolean useSoftDecoding = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerView = findViewById(R.id.player_view);
        urlInput = findViewById(R.id.url_input);
        playButton = findViewById(R.id.play_button);
        addVideoButton = findViewById(R.id.add_video_button);
        checkSelectedButton = findViewById(R.id.check_selected_button);
        audioSwitch = findViewById(R.id.audio_switch);
        videoSwitch = findViewById(R.id.video_switch);
        liveSwitch = findViewById(R.id.live_switch);
        decodeSwitch = findViewById(R.id.decode_switch);

        playButton.setOnClickListener(v -> {
            String url = urlInput.getText().toString();
            if (!url.isEmpty()) {
                playVideo(url);
            } else {
                Toast.makeText(this, "Please enter a video URL", Toast.LENGTH_SHORT).show();
            }
        });

        addVideoButton.setOnClickListener(v -> {
            Toast.makeText(this, "Add Video feature not implemented.", Toast.LENGTH_SHORT).show();
        });

        checkSelectedButton.setOnClickListener(v -> {
            Toast.makeText(this, "Currently selected video:
" + urlInput.getText().toString(), Toast.LENGTH_LONG).show();
        });

        audioSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isMuted = !isChecked;
            if (player != null) {
                player.setVolume(isMuted ? 0f : 1f);
            }
        });

        videoSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (playerView != null) {
                playerView.setVisibility(isChecked ? View.VISIBLE : View.INVISIBLE);
            }
        });

        liveSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Toast.makeText(this, isChecked ? "Live mode ON" : "Live mode OFF", Toast.LENGTH_SHORT).show();
        });

        decodeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            useSoftDecoding = isChecked;
            Toast.makeText(this, useSoftDecoding ? "Soft decoding" : "Hard decoding", Toast.LENGTH_SHORT).show();
        });
    }

    private void playVideo(String url) {
        if (player != null) {
            player.release();
        }

        RenderersFactory renderersFactory = new DefaultRenderersFactory(this)
                .setExtensionRendererMode(useSoftDecoding ? DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER_SOFTWARE
                                                          : DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF);

        player = new ExoPlayer.Builder(this, renderersFactory).build();
        playerView.setPlayer(player);

        MediaItem mediaItem = MediaItem.fromUri(Uri.parse(url));
        player.setMediaItem(mediaItem);
        player.prepare();
        player.setVolume(isMuted ? 0f : 1f);
        player.play();
        isPlaying = true;
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}